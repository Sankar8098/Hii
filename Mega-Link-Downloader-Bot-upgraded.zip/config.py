# Fill these with your own values (keep quotes)
API_ID = '123456'           # from my.telegram.org
API_HASH = 'your_api_hash'  # from my.telegram.org
BOT_TOKEN = '123456:ABC-DEF...'  # from BotFather

# Optional: Mega.nz account (needed for private files). For public links an anonymous login is used.
MEGA_EMAIL = ''
MEGA_PASSWORD = ''

# Where to save temporary downloads (must exist or be writable)
DOWNLOAD_DIR = '/tmp'  # change if needed
